# logistics-hs-landed-cost v0.1.0

**CrossAgent Lab skill pack** — Skillry-style: installable Agent Skill for Cursor / Claude.

## What you get

- `SKILL.md` — workflow the agent follows (HS / CBM via FreightUtils; optional border.bot)
- `references/mcp-freightutils.json` — remote MCP config skeleton (placeholders only)
- `references/mcp-borderbot.json` — optional OAuth MCP skeleton
- Hard HITL: never file customs or quote DDP without a human

## Clients

Cursor · Claude Desktop · Claude Code (remote MCP) · other agents that install Agent Skills

## Own keys

You bring your own accounts / keys / OAuth. This pack does **not** include API keys, Pro subscriptions, or border.bot credits. CrossAgent Lab does not hold or resell secrets.

- FreightUtils: anonymous eval OK; optional Pro key is yours  
- border.bot: your account, your OAuth, your credits

## Merch note (not a contract)

List price on CrossAgent Lab: **$4.99** (one-time download). Cases stay free:

- https://crossagent.maoxunxing.com/cases/freightutils-freight-mcp-cited-tools/
- https://crossagent.maoxunxing.com/cases/border-bot-hs-landed-cost-mcp/

## Install (buyer)

1. Unzip this pack into your agent’s skills directory (or paste `SKILL.md` where your client expects skills).
2. Add FreightUtils MCP from `references/mcp-freightutils.json`.
3. Ask: `Look up HS for cotton t-shirt` — expect a cited 6-digit HS, then wait for human review before any filing / quote.

## Version

0.1.0 · 2026-11-07 Asia/Shanghai · CrossAgent Lab
