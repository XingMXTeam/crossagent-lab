---
name: logistics-hs-landed-cost
description: >
  Look up WCO HS (6-digit) and freight math (CBM etc.) via FreightUtils MCP for
  cross-border ecommerce agents. Optional second path: border.bot for destination
  HS/HTS + landed cost (buyer OAuth + credits). Use when the user asks for HS code,
  tariff guess, CBM, chargeable weight, or landed-cost estimate. Read-only only —
  never file customs, quote DDP, or spend credits without an explicit human yes.
license: Proprietary — CrossAgent Lab skill pack (buyer license)
metadata:
  author: crossagent-lab
  version: "0.1.0"
  price_usd: "4.99"
  primary_mcp: "https://www.freightutils.com/api/mcp"
  optional_mcp: "https://mcp.border.bot/mcp"
  cases:
    - https://crossagent.maoxunxing.com/cases/freightutils-freight-mcp-cited-tools/
    - https://crossagent.maoxunxing.com/cases/border-bot-hs-landed-cost-mcp/
---

# Logistics HS / Landed Cost

Give the agent a **read-only** path to freight reference data (HS + CBM) before any
customs filing or customer quote. Primary path is FreightUtils (anonymous OK).
Optional path is border.bot (buyer OAuth + credits).

## When to use

- User asks for an HS / HTS guess from a product description or SKU name
- User needs CBM / chargeable-weight style freight math
- User wants a destination landed-cost **estimate** (use border.bot only after OAuth)
- User is preparing a quote and needs a cited reference row — not a final ruling

## Hard HITL (never skip)

Do **not** do any of the following without an explicit human confirmation in this chat:

1. Write HS / duty / ADR / landed-cost numbers onto a customs form, customer quote, product price, or DDP / checkout promise
2. Pick a final 8–10 digit national tariff line as “the” code
3. Book freight, buy a label, file an entry, change a price, or send an external commitment email
4. Complete FreightUtils Pro checkout or paste a real API key into chat
5. Approve border.bot OAuth / pick a billable workspace / spend classify or landed-cost credits
6. Treat medium confidence, FUZZY warnings, or illustrative figures as binding

If confidence is medium/low or a warning appears → stop, show the raw tool output, and ask the human.

## Setup (buyer brings keys)

### A. FreightUtils — primary (anonymous works)

Cursor / Claude Desktop remote MCP — see `references/mcp-freightutils.json`:

```json
{
  "mcpServers": {
    "freightutils": {
      "url": "https://www.freightutils.com/api/mcp"
    }
  }
}
```

Optional local stdio: `npx -y freightutils-mcp`  
Optional higher limits: buyer registers their own key at freightutils.com — put it in the client secret store as `FREIGHTUTILS_API_KEY`. Never commit a real key.

### B. border.bot — optional (OAuth + credits)

See `references/mcp-borderbot.json`. Endpoint: `https://mcp.border.bot/mcp`.  
Buyer signs in via the client’s OAuth flow and chooses a workspace. This Lab has **not** completed OAuth; do not invent classify / landed-cost totals.

## Workflow

1. Confirm goal is **reference only** (not filing / not DDP promise).
2. Prefer FreightUtils tools first:
   - `hs_code_lookup` with the product description (e.g. `cotton t-shirt`)
   - `cbm_calculator` when dimensions / pieces are known
   - Other read-only freight tools only if the user asked for them
3. Always surface from the tool response: HS code, description, confidence, warnings, `_source` / `citation`.
4. If the user needs destination HTS + duty/tax/fee/landed-cost lines and border.bot is connected + authorized → call its classify / landed-cost tools **only after** the human says yes to credit spend.
5. Output a short table + a line: `ACTIONS REQUIRING HUMAN APPROVAL`.
6. Stop. Do not file, quote DDP, or checkout.

## Verified sample (Lab live)

As of **2026-11-07 Asia/Shanghai**, anonymous FreightUtils:

| Call | Result |
| --- | --- |
| `initialize` | HTTP 200 · `freightutils-mcp` · version **2.34.0** |
| `GET …/health` | HTTP 200 · `status=ok` · `tools_registered=26` |
| `hs_code_lookup("cotton t-shirt")` | HTTP 200 · HS **610910** · confidence **medium** |

Do not invent other probe numbers. Older Lab case page (2026-10-26) also got HS 610910; tool count / version may drift — prefer live tool output over this table.

## Out of scope

- Reselling FreightUtils / border.bot keys or credits
- Customs brokerage, ADR acceptance, denied-party legal clearance
- Booking, labeling, filing, checkout
